<?php

$host = 'localhost'; // Put your host here
$db_username = 'root'; // Put your database username here
$db_password = ''; // Put your database password here
$db_name = 'facemash'; // Put your database name here
$mysqli = new mysqli($host, $db_username, $db_password, $db_name);
#if ($mysqli)
#  echo 'successful';

?>